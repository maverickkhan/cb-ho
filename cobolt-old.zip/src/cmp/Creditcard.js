import React, { Component } from 'react';
class Creditcard extends Component{
    render(){
        return(
            <div>
                <h3>Welcome to Credit card detail Page</h3>
                <p>Your credentials are safe and secure here.</p>
            </div>
        )
    }
}
export default Creditcard;