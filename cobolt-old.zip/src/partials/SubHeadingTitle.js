import React from 'react'
import './SubHeadingTitle.css';

export default function SubHeadingTitle({title, details}) {
    return (
        <div className="form-title-div">
            <h2 className="form-title-heading">{title}</h2>
            <p className="form-title-paragraph">{details}</p>
        </div>
    )
}

SubHeadingTitle.defaultProps = {
    title: "Project Name",
    details: " ",
}